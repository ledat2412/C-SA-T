﻿using MySqlConnector;
using VinhKhanh.Api.Data;
using VinhKhanh.Api.Dtos;

namespace VinhKhanh.Api.Services
{
    public class GianHangService
    {
        private readonly MySqlDbContext _db;

        public GianHangService(MySqlDbContext db)
        {
            _db = db;
        }

        public async Task<List<GianHangDto>> GetAllAsync(string lang = "vi")
        {
            var list = new List<GianHangDto>();

            using var conn = _db.GetConnection();
            await conn.OpenAsync();

            const string sql = @"
                SELECT 
                    gh.idGianHang,
                    COALESCE(ghnn.ten, gh.ten) AS ten,
                    gh.diaChi,
                    ghnn.moTa,
                    ghnn.audioURL,
                    gh.lat,
                    gh.lon
                FROM gianhang gh
                LEFT JOIN ngonngu nn 
                    ON nn.maNgonNgu = @lang
                LEFT JOIN gianhangngonngu ghnn 
                    ON ghnn.idGianHang = gh.idGianHang
                    AND ghnn.idNgonNgu = nn.idNgonNgu;";

            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@lang", lang);

            using var reader = await cmd.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                list.Add(new GianHangDto
                {
                    IdGianHang = reader.GetInt32("idGianHang"),
                    Ten = reader["ten"]?.ToString() ?? "",
                    DiaChi = reader["diaChi"]?.ToString(),
                    MoTa = reader["moTa"]?.ToString(),
                    AudioURL = reader["audioURL"]?.ToString(),
                    Lat = reader["lat"] == DBNull.Value ? null : Convert.ToDouble(reader["lat"]),
                    Lon = reader["lon"] == DBNull.Value ? null : Convert.ToDouble(reader["lon"])
                });
            }

            return list;
        }
    }
}