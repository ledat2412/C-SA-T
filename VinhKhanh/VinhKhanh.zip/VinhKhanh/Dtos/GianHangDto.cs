﻿namespace VinhKhanh.Api.Dtos
{
    public class GianHangDto
    {
        public int IdGianHang { get; set; }
        public string Ten { get; set; } = "";
        public string? DiaChi { get; set; }
        public string? MoTa { get; set; }
        public string? AudioURL { get; set; }
        public double? Lat { get; set; }
        public double? Lon { get; set; }
    }
}