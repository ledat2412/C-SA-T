﻿using Microsoft.AspNetCore.Mvc;
using VinhKhanh.Api.Services;

namespace VinhKhanh.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GianHangController : ControllerBase
    {
        private readonly GianHangService _service;

        public GianHangController(GianHangService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] string lang = "vi")
        {
            var data = await _service.GetAllAsync(lang);
            return Ok(data);
        }
    }
}